/*se encarga de cargar los usuarios a la base de datos*/
import fs from 'fs'; // es la que me permite leer archivos
import path from 'path'; // esta muestra la ruta actual
import csv from 'csv-parser';
import { pool } from "../conect_db.js"


export async function loadUsersToTheDatabase() {

    const filePath = path.resolve('server/data/users.csv');
    const users = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(filePath )
            .pipe(csv())
            .on("data", (fila) => {
                users.push([
                    fila.id_user,
                    fila.full_name.trim(),
                    fila.identification_number,
                    fila.address,
                    fila.number,
                    fila.email
                ]);
            })
            .on('end', async () => {
                try {
                    const sql = 'INSERT INTO users (id_user,full_name,identification_number,address,number,email) VALUES ?';
                    const [result] = await pool.query(sql, [users]);

                    console.log(`✅ They were inserted ${result.affectedRows} authors.`);
                    resolve(); 
                } catch (error) {
                    console.error('❌ Error inserting users:', error.message);
                    reject(error);
                }
            })
            .on('error', (err) => {
                console.error('❌  ERROR reading user CSV file:', err.message);
                reject(err);
            });
    });
}