/*se encarga de cargar los libros a la base de datos*/
import fs from 'fs'; // es la que me permite leer archivos
import path from 'path'; // esta muestra la ruta actual
import csv from 'csv-parser';
import { pool } from "../conect_db.js"


export async function uploadinvoicesThedatabase() {

    const filePath = path.resolve('server/data/invoice.csv');
    const invoice = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
            .pipe(csv())
            .on("data", (fila) => {
                invoice.push([
                    fila.id_invoice,
                    fila.id_user,
                    fila.invoice_number,
                    fila.platform_date,
                    fila.billing_period,
                    fila.invoice_amount,
                    fila.amount_paid

                ]);
            })
            .on('end', async () => {
                try {
                    const sql = 'INSERT INTO invoice (id_invoice,id_user,invoice_number,plataform_date, billing_period, invoice_amount,amount_paid) VALUES ?';
                    const [result] = await pool.query(sql, [invoice]);

                    console.log(`✅ They were inserted ${result.affectedRows} invoice.`);
                    resolve(); 
                } catch (error) {
                    console.error('❌ Error inserting books:', error.message);
                    reject(error);
                }
            })
            .on('error', (err) => {
                console.error('❌ ERROR reading CSV:', err.message);
                reject(err);
            });
    });
}