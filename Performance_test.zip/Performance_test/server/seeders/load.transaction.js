/*se encarga de cargar los prestamos a la base de datos*/
import fs from 'fs'; // es la que me permite leer archivos
import path from 'path'; // esta muestra la ruta actual
import csv from 'csv-parser';
import { pool } from "../conect_db.js"


export async function loadTransactionsToTheDatabase() {

    const filePath = path.resolve('server/data/transactionn.csv');
    const transactionn = [];

    return new Promise((resolve, reject) => {
        fs.createReadStream(filePath)
            .pipe(csv())
            .on("data", (fila) => {
                transactionn.push([
                    fila.id_transaction,
                    fila.id_user,
                    fila.date_transaction,
                    fila.time_transaction,
                    fila.amount,
                    fila.transaction_type
                ]);
            })
            .on('end', async () => {
                try {
                    const sql = 'INSERT INTO prestamos ( id_transaction,id_user,date_transaction,time_transaction,amount,transaction_type) VALUES ?';
                    const [result] = await pool.query(sql, [transactionn]);

                    console.log(`✅ They were inserted ${result.affectedRows} transaction.`);
                    resolve(); // Termina exitosamente
                } catch (error) {
                    console.error('❌ Error inserting loans:', error.message);
                    reject(error);
                }
            })
            .on('error', (err) => {
                console.error('❌ ERROR reading CSV FILE', err.message);
                reject(err);
            });
    });
}