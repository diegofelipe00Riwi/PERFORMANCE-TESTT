-- the database
DROP DATABASE IF EXISTS bank_registration;
CREATE DATABASE bank_registration;
USE bank_registration;

-- Table: users
DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id_user INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  identification_number VARCHAR(50) NOT NULL UNIQUE,
  address VARCHAR(100),
  phone_number VARCHAR(30),
  gmail VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table: transaction
DROP TABLE IF EXISTS transactions;
CREATE TABLE transactions (
  id_transaction VARCHAR(50) NOT NULL PRIMARY KEY,
  id_user INT,
  date_transaction DATE NOT NULL,
  time_transaction TIME NOT NULL,
  amount DECIMAL(10,2) DEFAULT NULL,
  transaction_type VARCHAR(100) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (id_user) REFERENCES users(id_user) ON DELETE SET NULL ON UPDATE CASCADE
);

-- Table: invoice
DROP TABLE IF EXISTS invoices;
CREATE TABLE invoices (
  id_invoice INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_user INT,
  invoice_number VARCHAR(50) NOT NULL UNIQUE,
  platform_date DATE NOT NULL,
  billing_period DATE,
  invoice_amount DECIMAL(10,2),
  amount_paid DECIMAL(10,2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (id_user) REFERENCES users(id_user) ON DELETE SET NULL ON UPDATE CASCADE
);

-- Table: status
DROP TABLE IF EXISTS statuss;
CREATE TABLE statuss (
  invoice_number VARCHAR(50) NOT NULL,
  status ENUM('completed', 'pending', 'failed') DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (invoice_number) REFERENCES invoices(invoice_number) ON DELETE CASCADE ON UPDATE CASCADE
);
