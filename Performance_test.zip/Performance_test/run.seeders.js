import { loadUsersToTheDatabase } from "./load_users.js";
import { loadTransactionsToTheDatabase} from "./load_transaction.js";
import { uploadinvoicesThedatabase} from "./load_invoice.js";

(async () => {
    try {
        console.log('Starting seeders...');

        await loadUsersToTheDatabase()
        await loadTransactionsToTheDatabase()
        await uploadinvoicesThedatabase()

        console.log('All seeders executed correctly. :D');
    } catch (error) {
        console.error('Error executing seeders:', error.message);
    } finally {
        process.exit();
    }
})()